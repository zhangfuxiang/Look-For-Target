﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CubeChangeColor : MonoBehaviour {

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
    public static CubeChangeColor instance;

    void Awake()
    {
        instance = this;
    }

    public void OnChangeColor()
    {
        gameObject.GetComponent<MeshRenderer>().material.color = new Color(Random.Range(0, 255) / 255f, Random.Range(0, 255) / 255f, Random.Range(0, 255) / 255f);
        Debug.Log("OnChangeColor");
    }
}
